// no need to change anything from here ... ----------------------

var letters = {};

var marginLeft = 20;
var marginTop = 50;
var textX = marginLeft;
var textY = 150;
var lineHeight = 120;
var typedText = "tp";

var mouseXs = [];
var mouseYs = [];

function setup() {
	createCanvas(windowWidth, windowHeight, WEBGL);
	ortho(-width / 2, width / 2, -height / 2, height / 2);
	initLetters();
	fill(0);
	//stroke(0);

	noStroke();
}

function draw() {
	background(255);

	mouseXs.push(mouseX);
	mouseYs.push(mouseY);
	if (mouseXs.length > 3) {
		mouseXs.shift();
		mouseYs.shift();
	}

	translate(-width / 2, -height / 2);
	tint(255, 127);
	scale(1.5);

	textX = marginLeft;
	textY = marginTop + 100;

	randomSeed(0);

	for (var i = 0; i < typedText.length; i++) {
		var c = typedText[i];
		if (letters[c]) {
			push();
			translate(textX, textY);

			var r = random(1, 3);

			for (var n = 0; n < mouseXs.length; n++) {
				// this part is for rotating each letter ---------------
				push();
				translate(50, -50, 0);
				rotateX(radians(mouseYs[n] - height / 2) / r);
		
				rotateY(radians(mouseXs[n] - width / 2) / r);
				translate(-50, 50, 0);
				// -----------------------------------------------------

				var w = letters[c]();
				pop();
			}

			textX += w;
			pop();
		} else if (c == "\n") {
			textX = marginLeft;
			textY += lineHeight;
		}
	}

}

function keyTyped() {
	if (letters[key]) {
		console.log(key)
		typedText += key;
	}
	if (keyCode == RETURN) {
		typedText += "\n";
	}
	if (keyCode == BACKSPACE || keyCode == DELETE) {
		if (typedText.length > 1) typedText = typedText.slice(0, -1);
		console.log(typedText);
	}

}
// ... to here -----------------------------------------------------


function initLetters() {
	// Add your calls to the letter functions here

	letters = {
		A: draw_A,
		t: draw_t,
		C: draw_C,
		p: draw_p,
		" ": function() { return 30 },
	};
}

// A function for each letter

function draw_A() {
	tint(255, 127); 
	push();
	translate(20, 0, 30);
	rotate(radians(20));
	rect(-10, -110, 20, 110);
	pop();

	push();
	translate(100, 0, -30);
	rotate(radians(-20));
	rect(-10, -110, 20, 110);
	pop();

	push();
	translate(30, -40, 0);
	rect(0, -10, 60, 20);
	pop();

	return 110;
}

function draw_t() {
	fill(0, 30);

	push();
	translate(30, 0, -10);
	rect(10, -40, 20, 40);
	pop();

	push();
	translate(70, 0, 40);
	rect(-30, -80, 20, 40);
	pop();

	push();
	translate(110, 0, -30);
	rect(-70, -105, 20, 25);
	pop();

	push();
	translate(100, 0, -10);
	rect(-95, -120, 90, 15);
	pop();

	push();
	translate(100, 0, 50);
	rect(-80, -105, 60, 15);
	pop();


	return 120;
}

function draw_p() {


	push();
	translate(30, 0, -10);
	rect(0, -40, 20, 40);
	pop();

	push();
	translate(70, 0, 40);
	rect(-40, -80, 20, 40);
	pop();

	push();
	translate(110, 0, -30);
	rect(-80, -105, 20, 25);
	pop();

	push();
	translate(100, 0, 50);
	rect(-60, -120, 45, 25);
	pop();

	push();
	translate(100, 0, 30);
	rect(-25, -110, 25, 15);
	pop();

	push();
	translate(100, 0, 70);
	rect(-15, -100, 20, 40);
	pop();

	push();
	translate(90, 0, 30);
	rect(-15, -65, 25, 15);
	pop();

	push();
	translate(100, 0, -30);
	rect(-60, -65, 45, 25);
	pop();

	return 100;
}

function draw_C() {

	push();
	translate(20, 0, 30);
	rotate(radians(20));
	rect(-10, -110, 20, 110);
	pop();

	push();
	translate(100, 0, -30);
	rotate(radians(-20));
	rect(-10, -110, 20, 110);
	pop();

	push();
	translate(30, -40, 0);
	rect(0, -10, 60, 20);
	pop();

	return 50;
}